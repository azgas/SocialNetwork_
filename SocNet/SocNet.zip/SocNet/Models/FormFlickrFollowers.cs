﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SocNet.Models
{
    public class FormFlickrFollowers
    {
        public string InitialVertex { get; set; }
        public int NetworkID { get; set; }
        public int NumberQueries { get; set; }
    }
}